import os
import numpy as np
import pandas as pd
from PIL import Image
from sklearn.linear_model import LinearRegression
import pickle

def extract_color_features(image_path):
    """提取图片的色彩特征（如平均饱和度、色调等）"""
    image = Image.open(image_path).convert('RGB')
    arr = np.array(image)
    # 转HSV
    hsv = np.array(image.convert('HSV'))
    mean_saturation = np.mean(hsv[..., 1])  # 平均饱和度
    mean_value = np.mean(hsv[..., 2])       # 平均明度
    std_saturation = np.std(hsv[..., 1])    # 饱和度标准差
    std_value = np.std(hsv[..., 2])         # 明度标准差
    return [mean_saturation, mean_value, std_saturation, std_value]

def train_color_model():
    # 读取标注数据
    df = pd.read_csv('data/color_scores.csv')  # 列: filename, score
    X = []
    y = []
    for _, row in df.iterrows():
        img_path = os.path.join('data/images', row['filename'])
        if os.path.exists(img_path):
            features = extract_color_features(img_path)
            X.append(features)
            y.append(row['score'])
    X = np.array(X)
    y = np.array(y)

    # 训练线性回归模型
    model = LinearRegression()
    model.fit(X, y)

    # 包装成带predict(image)接口的对象
    class ColorScoreModel:
        def __init__(self, model):
            self.model = model
        def predict(self, image_np):
            # image_np: numpy array (H, W, 3)
            image = Image.fromarray(image_np)
            features = extract_color_features_from_pil(image)
            return self.model.predict([features])[0]
    def extract_color_features_from_pil(image):
        hsv = np.array(image.convert('HSV'))
        mean_saturation = np.mean(hsv[..., 1])
        mean_value = np.mean(hsv[..., 2])
        std_saturation = np.std(hsv[..., 1])
        std_value = np.std(hsv[..., 2])
        return [mean_saturation, mean_value, std_saturation, std_value]

    color_model = ColorScoreModel(model)
    # 保存模型
    with open('color_model.pkl', 'wb') as f:
        pickle.dump(color_model, f)
    print('色彩评分模型已保存为 color_model.pkl')

if __name__ == '__main__':
    train_color_model() 
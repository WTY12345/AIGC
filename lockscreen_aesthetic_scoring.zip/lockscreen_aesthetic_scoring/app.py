import os
import pickle
from PIL import Image
import numpy as np
from flask import Flask, request, render_template, redirect, url_for
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif'}

if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# 加载模型（假设模型文件名如下）
MODEL_PATHS = {
    'color': 'color_model.pkl',
    'composition': 'composition_model.pkl',
    'depth': 'depth_model.pkl',
    'text_placement': 'text_placement_model.pkl',
    'occlusion': 'occlusion_model.pkl',
}

MODELS = {}
for key, path in MODEL_PATHS.items():
    full_path = os.path.join(os.path.dirname(__file__), path)
    if os.path.exists(full_path):
        with open(full_path, 'rb') as f:
            MODELS[key] = pickle.load(f)
    else:
        MODELS[key] = None  # 未训练模型时为None

def score_image(image_path):
    # 读取图片
    image = Image.open(image_path).convert('RGB')
    image_np = np.array(image)

    # 逐项评分
    scores = {}
    for key in ['color', 'composition', 'depth', 'text_placement', 'occlusion']:
        model = MODELS.get(key)
        if model is not None:
            try:
                score = float(model.predict(image_np))
            except Exception as e:
                score = 0.0
        else:
            score = 0.0  # 未训练模型时返回0分
        scores[key] = round(score, 1)

    # 综合评分
    overall = np.mean(list(scores.values()))
    scores['overall'] = round(overall, 1)
    return scores

@app.route('/', methods=['GET', 'POST'])
def upload_and_score():
    if request.method == 'POST':
        if 'file' not in request.files:
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(image_path)

            scores = score_image(image_path)
            image_url = f'uploads/{filename}'
            return render_template('index.html', scores=scores, image_url=image_url)

    return render_template('index.html', scores=None, image_url=None)

if __name__ == '__main__':
    app.run(debug=True) 